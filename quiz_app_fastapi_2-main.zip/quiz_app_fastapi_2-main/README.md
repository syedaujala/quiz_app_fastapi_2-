# quiz_app_fastapi_2
build quiz app by using fastapi
